const errorMessage = {
  message: 'Product not found',
};

module.exports = errorMessage;
